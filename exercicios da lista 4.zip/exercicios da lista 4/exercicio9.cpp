#include <iostream>

#define l 3
#define c 4
using namespace std;


enum mesesDoAno{
    janeiro ,
    fevereiro =2,
    marco = 3,
    abril = 4,
    maio = 5,
    junho = 6,
    julho =7,
    agosto = 8,
    setembro = 9,
    outubro = 10,
    novembro = 11,
    dezembro = 12
};

union myTypes{
    char endL;
    int i;
    float f;
}myTypes;

struct TiposDeMatriz{

    mesesDoAno mStatica[l][c];
    mesesDoAno** mDinamica;
};


int main()
{
    TiposDeMatriz TiposDeMatriz;
    myTypes.endL = '\n';

    short k = 1;

    for(int i = 0; i<l; i++)
    {
        for(int j = 0; j<c; j++)
        {
            TiposDeMatriz.mStatica[i][j] = (mesesDoAno)k++;
        }
        cout<<myTypes.endL;
    }

    cout<<"Matriz Estatica:\n\n";

    for(int i = 0; i<l; i++)
    {
        for(int j = 0; j<c; j++)
        {
            cout<<(mesesDoAno) TiposDeMatriz.mStatica[i][j];
        }
        cout<<myTypes.endL;
    }

    cout<<"\n\nMatriz Dinamica:\n";

    TiposDeMatriz.mDinamica = new mesesDoAno*[c];
    for(int i = 0; i<l; i++)
    {
        TiposDeMatriz.mDinamica[i] = new mesesDoAno[c];
    }

    k =1;
    for(int i = 0; i<l; i++)
    {
        for(int j = 0; j<c; j++)
        {
            TiposDeMatriz.mDinamica[i][j] = (mesesDoAno)k++;
        }
        cout<<myTypes.endL;
    }

    for(int i = 0; i<l; i++)
    {
        for(int j = 0; j<c; j++)
        {
            cout<<(mesesDoAno) TiposDeMatriz.mDinamica[i][j];
        }
        cout<<myTypes.endL;
    }
    delete TiposDeMatriz.mDinamica;
}
