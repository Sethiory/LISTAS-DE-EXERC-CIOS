java.lang.String
public class Caracteres
{

  public static void main(String[] args)
  {
    public char[] nome = new char[10] {'L','u','c','i','l','i','a','\n'};
    System.out.print(nome);
  }
}