#include <iostream>
#include<string>
using namespace std;

union people{
    char name[];
    int age;
    float weigh;

}people;

int main()
{

    people.name[60];
    cout<<"name:";
    cin.getline(people.name, 60);
    cout<<"age:";
    cin>>people.age;
    cout<<"weigh:";
    cin>>people.weigh;

    cout<<"-------------Data------------:\n";
    cout<<"name -> ";
    for(int i=0;people.name[i] != '\0'; i++)
    {
        cout<<people.name[i];
    }

    cout<<"\nage -> "<<people.age;
    cout<<"\nweigh -> "<<people.weigh<<" kg";

}
