#include <iostream>
using namespace std;

int main()
{
    char nome[10] = {'L','u','c','i','l','i','a','\n'};
    cout<<nome;
}
